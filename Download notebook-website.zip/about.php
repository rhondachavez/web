<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>About - Notebook</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body><?php include('navbar.php'); ?>
<div class="container py-5">
<h1>About Us</h1>
<p>We craft beautiful notebooks for students, professionals, and creatives. Our mission is to bring elegance and sustainability into everyday writing.</p>
<a href="index.php" class="btn btn-primary">Back to Home</a>
</div></body></html>
